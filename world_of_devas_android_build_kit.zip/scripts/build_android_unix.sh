#!/usr/bin/env bash
set -e

# === CONFIG ===
# Set this to your Godot 4.x HEADLESS binary path
# Example: GODOT_BIN="$HOME/Tools/godot-4.3-stable-linux.x86_64"
GODOT_BIN="${GODOT_BIN:-godot}"

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

echo ">> Project: $PROJECT_DIR"

# Create debug keystore if missing (standard Android debug keystore)
if [ ! -f "keystore/debug.keystore" ]; then
  echo ">> Generating debug keystore..."
  keytool -genkey -v -keystore keystore/debug.keystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
fi

# Export APK
echo ">> Exporting Android APK via Godot Headless..."
"$GODOT_BIN" --headless --verbose --path . --export-release "Android" "build/WorldOfDevas-debug.apk"

echo ">> Done. APK at: build/WorldOfDevas-debug.apk"