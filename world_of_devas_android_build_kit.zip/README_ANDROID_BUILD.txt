# World of Devas — Android Build Kit (Godot 4)

This kit helps you export an **APK** for Android using **Godot Headless**.

## What you need
1. **Godot 4.x Headless** binary installed (same version as your editor, e.g., 4.3).
2. **Java JDK 17** or newer (for `keytool`).
3. (Recommended) **Android SDK commandline-tools** installed. Not strictly required for simple template export.

> Make sure your regular Godot editor also has **Android Export Templates** installed (Editor → Manage Export Templates).
> The export preset is already included in `export_presets.cfg`.

## How to build (Windows)
1. Install JDK 17. Ensure `keytool` and `java` are in PATH.
2. Download Godot **Windows Headless** executable. Set environment variable `GODOT_BIN` to its full path (optional if in PATH).
3. Double-click: `scripts\build_android_windows.bat`
4. The APK is generated at: `build\WorldOfDevas-debug.apk`

## How to build (Linux / macOS)
1. Install JDK 17. Ensure `keytool` is in PATH.
2. Download Godot **headless** for your OS. Make sure it's in PATH, or set `GODOT_BIN` env var.
3. Run:
   ```bash
   chmod +x scripts/build_android_unix.sh
   ./scripts/build_android_unix.sh
   ```
4. The APK appears at: `build/WorldOfDevas-debug.apk`

## Signing
These scripts generate a standard **debug keystore** automatically (password `android`), and the preset uses it to sign the APK. For release builds, replace with your own keystore and update the preset accordingly.

## Troubleshooting
- **'godot: command not found'** → Set `GODOT_BIN` to your headless binary path.
- **'keytool: command not found'** → Install JDK 17 and add it to PATH.
- **'No export templates found'** → In the Godot editor, install Android Export Templates.
- **APK installs but crashes** → Ensure your Android version supports the chosen architectures (ARM64/ARMv7). Try enabling both in the preset (already enabled).

Enjoy! 🚀